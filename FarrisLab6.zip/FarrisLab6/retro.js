let x1 = 220;
let y1 = 640;
let w1 = 40;
let h1 = 30;
let move = 5;
let right = 430;
let left = 19;
let Height = 200;
let bottom = 400;
let angle = 0;
let y = 0;


function setup() {
  createCanvas(500, 700);
  background(51);
  angleMode(DEGREES);
}

function draw() {
  background(0);
  strokeWeight(3);
  fill(255);
 // rect(1, 1, 498, 20); // Top border
  rect(1, 679, 498, 20); // Bottom border
  rect(1, 1, 20, 679); // Left border
  rect(479, 1, 20, 679); // Right border
  rect(x1, y1, w1, h1); // Character
  
if (x1 < left) { // Setting Border
    x1 = x1 + move;
  }
else if (x1 > right) { // Setting Border
    x1 = x1 - move;
  }
  movement();
  framerate();
  objects(y);
   if (y < 50) {
      objects(y);
      }
  stroke(2);
  
} // End main

function movement() {
  //Movement
for (let i = 0; i < 1; i++) { 
    if (keyIsPressed) {
      if (key == 'a') {
      x1 = x1 - move; 
  }
    else if (keyIsPressed) {
      if (key == 'd') {
        x1 = x1 + move;
    
    }
      else if (keyIsPressed) {
      if (key == 'w') {
        y1 = y1 - move;
          }
        }
      }  
    }
  }
}

function objects() {
  //Objects
  
  push();
  translate(80, 630);
  stroke(255);
  rotate(angle);
  line(0, 0, 50, 50);
  angle = angle + 1;
  pop();
  
  push();
  translate(80, 150);
  stroke(255);
  rotate(angle);
  line(0, 0, 50, 50);
  angle = angle + 1;
  pop();
  
  push();
  translate(420, 150);
  stroke(255);
  rotate(-angle);
  line(0, 0, 50, 50);
  angle = angle + 1;
  pop();
  
  push();
  translate(420, 630);
  stroke(255);
  rotate(-angle);
  line(0, 0, 50, 50);
  angle = angle + 1;
  pop();
  
  push();
  translate(250, 250);
  stroke(255);
  rotate(-angle);
  scale(mouseX / 100);
  line(0, 0, 50, 50);
  angle = angle + 1;
  pop();
  
  push();
  translate(mouseX, 0);
  rect(0, 400, 600, 30); // Top rect
  rect(-500, 480, 900, 30); // Middle rect
  rect(0, 550, 600, 30);
  rect(-500, 330, 900, 30); 
  rect(0, 240, 600, 30);
  rect(-500, 150, 900, 30); 
  rect(0, 75, 600, 30); 
  pop();
}

function framerate() {
  let fr = abs(60); // absolute setting fr to 30
  frameRate(fr); 
  print(fr); // prints framerate to console
  return fr;

}