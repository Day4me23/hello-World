function setup() {
  createCanvas(400, 400);
  background(1);
}

function draw() {
  // Earth
  strokeWeight(1);
  let c = color(175, 100, 220); // Blue
  fill(c);
  let blueValue = blue(c);
  fill(0, 0, blueValue);
  stroke(150);
  ellipse(-50, 380, 500, 500);
  
  let lg = color('hsl(160, 100%, 50%)'); // Light Green
  strokeWeight(1);
  fill(lg);
  beginShape();
  vertex(69, 250); // B Right
  vertex(54, 236); // T Right
  vertex(32, 232); // T Left
  vertex(13, 250); // B Left
  vertex(43, 270); // B Point
  vertex(66, 265); // M Left
  endShape(CLOSE);
  
  // Land on Earth
  beginShape();
  vertex(70, 310);
  vertex(97, 288);
  vertex(134, 333);
  vertex(117, 376);
  vertex(57, 334);
  vertex(35, 300);
  endShape(CLOSE);
  
  beginShape();
  vertex(10, 379);
  vertex(23, 359);
  vertex(96, 388);
  vertex(78, 395);
  vertex(46, 477);
  endShape();
  
  beginShape();
  vertex(5, 330);
  vertex(15, 356);
  vertex(40, 343);
  vertex(46, 334);
  vertex(19, 300);
  vertex();
  endShape();
  
  quad(166, 356, 179, 344, 188, 367, 174, 388);
  
  quad(9, 190, 13, 210, 37, 203, 23, 167);
  
  quad(102, 197, 57, 202, 117, 293, 155, 346);
  
  // Saturn
  strokeWeight(.5)
  stroke(50);
  g = color('hsba(160, 100%, 50%, .5)'); // Green
  fill(g);
  ellipse(300, 100, 150, 150);
  
  // Saturn Rings Points
  noFill();
  strokeWeight(1);
  point(225, 90); // Top Middle Left
  point(190, 155); // Top Left
  point(270, 155); // Bottom Left
  point(340, 130); // Middle Right
  point(380, 95); // Bottom Right
  point(400, 62); // Top Right
  //point(370, 60); // Top Middle Right
  
  // Saturn Rings Curves
  strokeWeight(2);
  stroke(50);
  noFill();
  beginShape();
  curveVertex(225, 110);
  curveVertex(225, 110);
  curveVertex(190, 155);
  curveVertex(270, 155);
  curveVertex(340, 130);
  curveVertex(380, 95);
  curveVertex(400, 62);
  curveVertex(365, 60);
  curveVertex(365, 60);
  endShape();
  
  // Yellow Stars
  strokeWeight(2);
  let y = color(255, 204, 0); // Yellow Coloring
  stroke(y);
  point(67, 23);
  point(108, 69);
  point(179, 49);
  point(138, 24);
  point(246, 33);
  point(213, 22);
  point(68, 87);
  point(13, 86);
  point(185, 84);
  point(17, 119);
  point(91, 113);
  point(167, 122);
  point(184, 220);
  point(232, 169);
  point(367, 285);
  point(274, 179);
  point(347, 366);
  point(264, 292);
  point(390, 100);
  point(347, 167);
  point(330, 199);
  point(233, 200);
  point(191, 270);
  point(291, 202);
  point(377, 174);
  point(329, 274);
  point(312, 340);
  point(222, 389);
  
  // White Stars
  stroke(255);
  point(95, 33);
  point(278, 377);
  point(300, 16);
  point(376, 322);
  point(367, 224);
  point(376, 35);
  point(34, 54);
  point(379, 379);
  point(129, 94);
  point(225, 257);
  point(47, 123);
  point(380, 143);
  point(99, 147);
  point(207, 312);
  point(143, 167);
  point(391, 269);
  point(192, 187);
  point(245, 345);
  point(306, 246);
  point(257, 236);
  
  // Moon
  stroke(170);
  fill(50);
  strokeWeight(.5);
  arc(25, -2, 75, 75, 0, PI + TWO_PI, CHORD);
  strokeWeight(0);
  fill(80);
  ellipse(25, 2, 60, 50);
 
  // Comet
  fill(255);
  strokeWeight(1);
  stroke(.5);
  let r = color(255, 204, 0); // Red Comet Color
  fill(r);
  let redValue = red(r); 
  fill(redValue, 0, 0);
  beginShape();
  vertex(280, 320); // Front Point
  vertex(290, 330); // Bot Right
  vertex(335, 320); // End Tail
  vertex(290, 310); // Top Point
  endShape(CLOSE);
  stroke(200);
  let by = color(255, 204, 0);
  stroke(by);
  fill(by);
  line(295, 311, 319, 307); 
  line(295, 329, 319, 333); 
  line(310, 315, 325, 315); 
  line(310, 325, 325, 325); 
  line(295, 320, 325, 320); 
  
  // Comet Beam
  fill(50);
  strokeWeight(.5);
  quad(291, 314, 286, 320, 288, 324, 292, 317);
  noFill();
  
}