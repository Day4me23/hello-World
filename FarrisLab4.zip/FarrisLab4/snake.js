let vl = 230; // Vertical W variable
let hz = 240; // Horizontal variable

function setup() {
	createCanvas(500, 500); // Setting canvas size
    background(21); // Background color
}

function mouseClicked() { // Mouse clicked fuction which creates the square in the center
    let c = color(0, 75, 0); // Green coloring
    fill(c);
    rect(240, 230, 30, 30); // Starting Rect
    }

function draw() {
  strokeWeight(5);
  let b = color(50, 55, 100); // Blue coloring
  fill(b);
  rect(1, 1, 20, 499); // Left Border
  rect(22, 480, 477, 20); // Bottom Border
  rect(479, 1, 20, 499); // Right Border
  rect(22, 1, 456, 20); // Top Border
  
  for (let i = 0; i < 1; i++) { // Loop that allows the user to continue to adjust the snake movement
  let c = color(0, 75, 0); // Green coloring
  fill(c);
  strokeWeight(3);
  if (keyIsPressed) {
    if (key == 'w') { // Checks for key w to be pressed
       rect(hz, vl, 30, 30); // Draws the shape
       vl = vl - 30; // Adjusts to where the next square needs to be placed based on next key
    }
    else if (key == 'a') { // Checks for key a to be pressed
      rect(hz, vl, 30, 30); // Draws the shape
      hz = hz - 30; // Adjusts to where the next square needs to be placed based on next key
    }
    else if (key == 's') { // Checks for key s to be pressed
      rect(hz, vl, 30, 30);   // Draws the shape
      vl = vl + 30; // Adjusts to where the next square needs to be placed based on next key
    }
    else if (key == 'd') { // Checks for key d to be pressed
      rect(hz, vl, 30, 30);   // Draws the shape
      hz = hz + 30; // Adjusts to where the next square needs to be placed based on next key
      } 
    }
  }
}
